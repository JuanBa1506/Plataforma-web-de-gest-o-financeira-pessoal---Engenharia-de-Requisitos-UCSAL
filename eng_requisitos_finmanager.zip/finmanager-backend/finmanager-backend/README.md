# FinManager

Plataforma web de gestão financeira pessoal (UCSAL – Engenharia de Requisitos).
Back-end em **Spring Boot 3 / Java 17** com banco de dados **H2** (arquivo) ou **PostgreSQL**, e front-end em HTML, CSS e JavaScript servido pelo próprio Spring.

## Como rodar
Requisitos: JDK 17+ e Maven 3.9+.

```bash
mvn spring-boot:run
```

Abra http://localhost:8080, clique em **Criar conta** e entre com o e-mail e a senha cadastrados.

- Console do banco (H2): http://localhost:8080/h2-console
  - JDBC URL: `jdbc:h2:file:./data/finmanager;AUTO_SERVER=TRUE` · usuário `sa` · senha em branco
- PostgreSQL: crie o banco `finmanager`, ajuste `application-postgres.properties` e rode
  `mvn spring-boot:run -Dspring-boot.run.profiles=postgres`

## Telas com back-end funcional
Cadastro/login, Contas, Categorias, Transações, Orçamentos, Metas, Recorrências, Importação de extrato e Notificações. Todas gravam no banco.

## Regras implementadas
| Requisito | Onde |
|---|---|
| RN01 – sessão expira após 15 min sem interação | `server.servlet.session.timeout=15m` |
| RNF02 – senhas com BCrypt, cookie de sessão HttpOnly | `SecurityConfig` |
| RF02 – saldo recalculado a cada lançamento | front soma transações efetivadas + saldo inicial |
| RF03 – lançamento com comprovante opcional | `POST /api/transacoes` (guarda o nome do arquivo) |
| RF04 – importação .CSV/.OFX com conferência | leitura no front, gravação em `POST /api/transacoes/lote` |
| RF05 – categorias em até 3 níveis | `FinService.criarCategoria` |
| RF06 – alerta ao atingir % do limite | `FinService.alerta` (gera notificação) |
| RF07 – metas e aportes | `POST /api/metas`, `/metas/{id}/aporte` |
| RF08 – recorrências geram pendências | `FinService.processar` e rotina diária `@Scheduled` |
| RF10 – avisos 3 e 1 dia antes do vencimento | `FinService.rotinaDiaria` (e-mail/push apenas simulados no log) |

## Endpoints (`/api`, exigem login, exceto `auth/*`)
| Método | Rota | Função |
|---|---|---|
| POST | `/auth/register`, `/auth/login`, `/auth/logout`, `/auth/recuperar` | acesso |
| GET | `/auth/me`, `/state` | usuário logado / todos os dados do usuário |
| POST, DELETE | `/contas`, `/contas/{id}` | contas |
| POST, DELETE | `/categorias`, `/categorias/{id}` | categorias |
| POST, DELETE | `/transacoes`, `/transacoes/{id}` | transações |
| POST | `/transacoes/lote`, `/transacoes/{id}/confirmar` | importação / confirmar pendência |
| PUT, DELETE | `/limites`, `/limites/{categoriaId}` | limites |
| POST, DELETE | `/metas`, `/metas/{id}/aporte`, `/metas/{id}` | metas |
| POST, DELETE | `/agendamentos`, `/agendamentos/processar`, `/agendamentos/{id}` | recorrências |
| POST, DELETE | `/notificacoes/lidas`, `/notificacoes`, `/notificacoes/{id}` | notificações |

Cada usuário só enxerga e altera os próprios dados (toda consulta filtra pelo id do usuário logado).

## Estrutura
```
src/main/java/br/ucsal/finmanager
  config/   SecurityConfig, Logado
  model/    entidades JPA
  repo/     repositórios Spring Data
  service/  FinService (regras de negócio)
  web/      AuthController, ApiController, Erros
src/main/resources
  static/   front-end (index.html, style.css, app.js)
  application.properties
```

## Fora do escopo desta versão
Exportação XLSX/PDF pelo servidor, envio real de e-mail/push, verificação em duas etapas (removida a pedido) e o perfil Administrador (o campo `perfil` existe na tabela `usuario`, mas ainda não há telas ou rotas de admin).
