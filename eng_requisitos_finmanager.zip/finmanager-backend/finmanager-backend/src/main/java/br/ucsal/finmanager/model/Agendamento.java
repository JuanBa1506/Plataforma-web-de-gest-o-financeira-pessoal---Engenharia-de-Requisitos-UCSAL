package br.ucsal.finmanager.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import java.math.BigDecimal;
import java.time.LocalDate;

@Entity
@Table(name = "agendamento")
public class Agendamento {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY) public Long id;
    @Column(name = "descricao", nullable = false) public String desc;
    @Column(precision = 15, scale = 2, nullable = false) public BigDecimal valor;
    /** Diária | Mensal | Semestral | Anual */
    @Column(name = "periodicidade", nullable = false) public String per;
    @Column(name = "proxima_data", nullable = false) public LocalDate prox;
    @Column(name = "categoria_id") public Long cat;
    @Column(name = "conta_id", nullable = false) public Long conta;
    @Column(nullable = false) public String tipo;
    @JsonIgnore @Column(name = "usuario_id", nullable = false) public Long usuarioId;
}
