package br.ucsal.finmanager.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import java.math.BigDecimal;
import java.time.LocalDate;

@Entity
@Table(name = "limite_orcamentario")
public class Limite {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY) public Long id;
    @Column(name = "categoria_id", nullable = false) public Long cat;
    @Column(name = "valor_teto", precision = 15, scale = 2, nullable = false) public BigDecimal teto;
    @Column(name = "percentual_atencao", nullable = false) public Integer pct;
    @JsonIgnore @Column(name = "usuario_id", nullable = false) public Long usuarioId;
}
