package br.ucsal.finmanager;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableScheduling;

@SpringBootApplication
@EnableScheduling
public class FinManagerApplication {
    public static void main(String[] args) {
        SpringApplication.run(FinManagerApplication.class, args);
    }
}
