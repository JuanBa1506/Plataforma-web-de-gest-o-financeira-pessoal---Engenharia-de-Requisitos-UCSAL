package br.ucsal.finmanager.repo;

import br.ucsal.finmanager.model.*;
import java.util.*;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ContaRepo extends JpaRepository<Conta, Long> {
    List<Conta> findByUsuarioId(Long u);
    Optional<Conta> findByIdAndUsuarioId(Long id, Long u);
    long countByUsuarioId(Long u);
}
