package br.ucsal.finmanager.service;

import br.ucsal.finmanager.model.*;
import br.ucsal.finmanager.repo.*;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDate;
import java.time.YearMonth;
import java.util.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.server.ResponseStatusException;

/** Regras de negócio do FinManager. Toda consulta é filtrada pelo id do usuário logado. */
@Service
@Transactional
public class FinService {
    private static final Logger log = LoggerFactory.getLogger(FinService.class);
    private static final Set<String> PERIODOS = Set.of("Diária", "Mensal", "Semestral", "Anual");

    private final UsuarioRepo users;
    private final ContaRepo contas;
    private final CategoriaRepo cats;
    private final TransacaoRepo txs;
    private final LimiteRepo lims;
    private final MetaRepo metas;
    private final AgendamentoRepo ags;
    private final NotificacaoRepo nots;
    private final PasswordEncoder enc;

    public FinService(UsuarioRepo users, ContaRepo contas, CategoriaRepo cats, TransacaoRepo txs, LimiteRepo lims,
                      MetaRepo metas, AgendamentoRepo ags, NotificacaoRepo nots, PasswordEncoder enc) {
        this.users = users; this.contas = contas; this.cats = cats; this.txs = txs; this.lims = lims;
        this.metas = metas; this.ags = ags; this.nots = nots; this.enc = enc;
    }

    public record Estado(List<Conta> contas, List<Categoria> cats, List<Transacao> tx, List<Limite> lim,
                         List<Meta> metas, List<Agendamento> ag, List<Notificacao> notifs) {}

    /* ---------- utilitários ---------- */
    private static ResponseStatusException bad(String m) { return new ResponseStatusException(HttpStatus.BAD_REQUEST, m); }
    private ResponseStatusException nf() { return new ResponseStatusException(HttpStatus.NOT_FOUND, "Registro não encontrado."); }
    private static String req(String s, String m) { if (s == null || s.isBlank()) throw bad(m); return s.trim(); }
    private static BigDecimal pos(BigDecimal v, String m) { if (v == null || v.signum() <= 0) throw bad(m); return v; }
    private static String tipo(String t) {
        if (!"Receita".equals(t) && !"Despesa".equals(t)) throw bad("O tipo deve ser Receita ou Despesa.");
        return t;
    }
    private static LocalDate proxima(LocalDate d, String per) {
        return switch (per) {
            case "Diária" -> d.plusDays(1);
            case "Mensal" -> d.plusMonths(1);
            case "Semestral" -> d.plusMonths(6);
            default -> d.plusYears(1);
        };
    }
    private Long catValida(Long u, Long id) {
        if (id == null) return null;
        cats.findByIdAndUsuarioId(id, u).orElseThrow(() -> bad("Categoria inválida."));
        return id;
    }
    private Long contaValida(Long u, Long id) {
        if (id == null) throw bad("Selecione uma conta.");
        contas.findByIdAndUsuarioId(id, u).orElseThrow(() -> bad("Conta inválida."));
        return id;
    }
    private Set<Long> descendentes(Long u, Long id) {
        List<Categoria> todas = cats.findByUsuarioId(u);
        Set<Long> r = new HashSet<>();
        Deque<Long> fila = new ArrayDeque<>(List.of(id));
        while (!fila.isEmpty()) {
            Long x = fila.pop();
            if (r.add(x)) todas.stream().filter(c -> x.equals(c.pai)).forEach(c -> fila.push(c.id));
        }
        return r;
    }
    private int nivel(Long u, Long id) {
        int n = 0;
        Long atual = id;
        while (atual != null) {
            Categoria c = cats.findByIdAndUsuarioId(atual, u).orElseThrow(() -> bad("Categoria inválida."));
            n++;
            atual = c.pai;
        }
        return n;
    }

    /* ---------- cadastro ---------- */
    public Usuario registrar(String nome, String email, String senha) {
        req(nome, "Informe o nome.");
        if (email == null || !email.trim().matches("^[^@\\s]+@[^@\\s]+\\.[^@\\s]+$")) throw bad("E-mail inválido.");
        if (senha == null || senha.length() < 8) throw bad("A senha deve ter ao menos 8 caracteres.");
        String em = email.trim().toLowerCase();
        if (users.existsByEmail(em)) throw new ResponseStatusException(HttpStatus.CONFLICT, "Este e-mail já está cadastrado.");
        Usuario u = new Usuario();
        u.nome = nome.trim();
        u.email = em;
        u.senhaHash = enc.encode(senha);
        users.save(u);
        Conta c = new Conta();
        c.nome = "Carteira"; c.tipo = "Carteira física"; c.usuarioId = u.id;
        contas.save(c);
        for (String n : List.of("Moradia", "Alimentação", "Transporte", "Lazer", "Saúde", "Salário")) {
            Categoria k = new Categoria();
            k.nome = n; k.usuarioId = u.id;
            cats.save(k);
        }
        return u;
    }

    @Transactional(readOnly = true)
    public Estado estado(Long u) {
        return new Estado(contas.findByUsuarioId(u), cats.findByUsuarioId(u), txs.findByUsuarioId(u),
                lims.findByUsuarioId(u), metas.findByUsuarioId(u), ags.findByUsuarioId(u),
                nots.findByUsuarioIdOrderByIdDesc(u));
    }

    /* ---------- contas (RF02) ---------- */
    public Conta criarConta(Long u, Conta in) {
        Conta c = new Conta();
        c.nome = req(in.nome, "Informe o nome da conta.");
        c.tipo = in.tipo == null ? "Conta corrente" : in.tipo;
        c.ini = in.ini == null ? BigDecimal.ZERO : in.ini;
        c.usuarioId = u;
        return contas.save(c);
    }
    public void removerConta(Long u, Long id) {
        Conta c = contas.findByIdAndUsuarioId(id, u).orElseThrow(this::nf);
        if (contas.countByUsuarioId(u) <= 1) throw bad("Mantenha ao menos uma conta.");
        txs.deleteByContaAndUsuarioId(id, u);
        ags.deleteByContaAndUsuarioId(id, u);
        contas.delete(c);
    }

    /* ---------- categorias (RF05: até 3 níveis) ---------- */
    public Categoria criarCategoria(Long u, Categoria in) {
        Categoria c = new Categoria();
        c.nome = req(in.nome, "Informe o nome da categoria.");
        if (in.pai != null && nivel(u, in.pai) >= 3) throw bad("Limite de 3 níveis atingido. Escolha outra categoria pai.");
        c.pai = in.pai;
        c.usuarioId = u;
        return cats.save(c);
    }
    public void removerCategoria(Long u, Long id) {
        cats.findByIdAndUsuarioId(id, u).orElseThrow(this::nf);
        Set<Long> ids = descendentes(u, id);
        lims.deleteByCatInAndUsuarioId(ids, u);
        txs.findByUsuarioId(u).stream().filter(t -> t.cat != null && ids.contains(t.cat)).forEach(t -> t.cat = null);
        ags.findByUsuarioId(u).stream().filter(a -> a.cat != null && ids.contains(a.cat)).forEach(a -> a.cat = null);
        cats.findByUsuarioId(u).stream().filter(c -> ids.contains(c.id)).forEach(cats::delete);
    }

    /* ---------- transações (RF03/RF04) ---------- */
    /** Retorna a mensagem de alerta de limite (ou null). */
    public String criarTransacao(Long u, Transacao in) {
        Transacao t = new Transacao();
        t.desc = req(in.desc, "Informe a descrição.");
        t.valor = pos(in.valor, "O valor deve ser maior que zero.");
        t.data = in.data == null ? LocalDate.now() : in.data;
        t.tipo = tipo(in.tipo);
        t.forma = in.forma;
        t.cat = catValida(u, in.cat);
        t.conta = contaValida(u, in.conta);
        t.status = "Efetivada";
        t.comp = in.comp;
        t.usuarioId = u;
        txs.save(t);
        return alerta(u, t);
    }
    public int importar(Long u, List<Transacao> itens) {
        Long conta = contas.findByUsuarioId(u).stream().findFirst()
                .orElseThrow(() -> bad("Cadastre uma conta antes de importar.")).id;
        for (Transacao i : itens) {
            Transacao t = new Transacao();
            t.desc = req(i.desc, "Há lançamento sem descrição no extrato.");
            t.valor = pos(i.valor, "Há lançamento com valor inválido no extrato.");
            t.data = i.data == null ? LocalDate.now() : i.data;
            t.tipo = tipo(i.tipo);
            t.forma = "Importado";
            t.conta = conta;
            t.usuarioId = u;
            txs.save(t);
            alerta(u, t);
        }
        return itens.size();
    }
    public String confirmar(Long u, Long id) {
        Transacao t = txs.findByIdAndUsuarioId(id, u).orElseThrow(this::nf);
        if (!"Pendente".equals(t.status)) throw bad("Apenas pendências podem ser confirmadas.");
        t.status = "Efetivada";
        return alerta(u, t);
    }
    public void removerTransacao(Long u, Long id) {
        txs.delete(txs.findByIdAndUsuarioId(id, u).orElseThrow(this::nf));
    }

    /** RF06: dispara notificação quando o gasto do mês atinge o percentual configurado. */
    private String alerta(Long u, Transacao t) {
        if (!"Despesa".equals(t.tipo) || !"Efetivada".equals(t.status) || t.cat == null) return null;
        YearMonth ym = YearMonth.now();
        String msg = null;
        for (Limite l : lims.findByUsuarioId(u)) {
            Set<Long> ids = descendentes(u, l.cat);
            if (!ids.contains(t.cat)) continue;
            BigDecimal gasto = txs.gasto(u, ids, ym.atDay(1), ym.atEndOfMonth());
            int p = gasto.multiply(BigDecimal.valueOf(100)).divide(l.teto, 0, RoundingMode.HALF_UP).intValue();
            if (p >= l.pct) {
                String nome = cats.findById(l.cat).map(c -> c.nome).orElse("Categoria");
                msg = p >= 100 ? "Limite de " + nome + " ultrapassado." : nome + " chegou a " + p + "% do limite mensal.";
                nots.save(Notificacao.de(u, msg));
            }
        }
        return msg;
    }

    /* ---------- orçamentos ---------- */
    public Limite definirLimite(Long u, Limite in) {
        if (in.cat == null) throw bad("Selecione a categoria.");
        catValida(u, in.cat);
        pos(in.teto, "O limite deve ser maior que zero.");
        if (in.pct == null || in.pct < 1 || in.pct > 100) throw bad("O percentual de alerta deve estar entre 1 e 100.");
        Limite l = lims.findByCatAndUsuarioId(in.cat, u).orElseGet(Limite::new);
        l.cat = in.cat; l.teto = in.teto; l.pct = in.pct; l.usuarioId = u;
        return lims.save(l);
    }
    public void removerLimite(Long u, Long cat) {
        lims.delete(lims.findByCatAndUsuarioId(cat, u).orElseThrow(this::nf));
    }

    /* ---------- metas (RF07) ---------- */
    public Meta criarMeta(Long u, Meta in) {
        Meta m = new Meta();
        m.nome = req(in.nome, "Informe o nome da meta.");
        m.alvo = pos(in.alvo, "O valor final deve ser maior que zero.");
        m.aporte = in.aporte;
        m.fim = in.fim;
        m.usuarioId = u;
        return metas.save(m);
    }
    public Meta aportar(Long u, Long id, BigDecimal valor) {
        pos(valor, "Informe um aporte maior que zero.");
        Meta m = metas.findByIdAndUsuarioId(id, u).orElseThrow(this::nf);
        m.acum = m.acum.add(valor).min(m.alvo);
        return m;
    }
    public void removerMeta(Long u, Long id) {
        metas.delete(metas.findByIdAndUsuarioId(id, u).orElseThrow(this::nf));
    }

    /* ---------- recorrências (RF08/RF10) ---------- */
    public Agendamento criarAgendamento(Long u, Agendamento in) {
        Agendamento a = new Agendamento();
        a.desc = req(in.desc, "Informe a descrição.");
        a.valor = pos(in.valor, "O valor deve ser maior que zero.");
        if (!PERIODOS.contains(in.per)) throw bad("Periodicidade inválida.");
        a.per = in.per;
        a.prox = in.prox == null ? LocalDate.now() : in.prox;
        a.cat = catValida(u, in.cat);
        a.conta = contaValida(u, in.conta);
        a.tipo = tipo(in.tipo);
        a.usuarioId = u;
        return ags.save(a);
    }
    public void removerAgendamento(Long u, Long id) {
        ags.delete(ags.findByIdAndUsuarioId(id, u).orElseThrow(this::nf));
    }
    /** Gera uma pendência para cada recorrência do usuário e avança a próxima data. */
    public int processar(Long u) {
        List<Agendamento> lista = ags.findByUsuarioId(u);
        lista.forEach(this::gerarPendencia);
        return lista.size();
    }
    private void gerarPendencia(Agendamento a) {
        Transacao t = new Transacao();
        t.desc = a.desc; t.valor = a.valor; t.data = a.prox; t.tipo = a.tipo; t.forma = "Recorrente";
        t.cat = a.cat; t.conta = a.conta; t.status = "Pendente"; t.usuarioId = a.usuarioId;
        txs.save(t);
        a.prox = proxima(a.prox, a.per);
    }
    /** Rotina diária: gera pendências vencidas e avisa vencimentos em 3 e 1 dia(s). */
    @Scheduled(cron = "0 0 6 * * *")
    public void rotinaDiaria() {
        LocalDate hoje = LocalDate.now();
        for (Agendamento a : ags.findByProxLessThanEqual(hoje)) {
            while (!a.prox.isAfter(hoje)) gerarPendencia(a);
        }
        for (int dias : new int[]{3, 1}) {
            for (Agendamento a : ags.findByProx(hoje.plusDays(dias))) {
                String m = a.desc + " vence em " + dias + (dias == 1 ? " dia." : " dias.");
                nots.save(Notificacao.de(a.usuarioId, m));
                log.info("[e-mail/push simulado] usuário {}: {}", a.usuarioId, m);
            }
        }
    }

    /* ---------- notificações (RF10) ---------- */
    public void marcarLidas(Long u) { nots.findByUsuarioIdOrderByIdDesc(u).forEach(n -> n.lida = true); }
    public void removerNotificacao(Long u, Long id) {
        nots.delete(nots.findByIdAndUsuarioId(id, u).orElseThrow(this::nf));
    }
    public void limparNotificacoes(Long u) { nots.deleteByUsuarioId(u); }
}
