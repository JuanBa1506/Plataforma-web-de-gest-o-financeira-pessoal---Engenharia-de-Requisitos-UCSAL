package br.ucsal.finmanager.config;

import br.ucsal.finmanager.model.Usuario;
import java.util.List;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.User;

/** Usuário autenticado guardado na sessão HTTP. */
public class Logado extends User {
    public final Long id;
    public final String nome;

    public Logado(Usuario u) {
        super(u.email, u.senhaHash, List.of(new SimpleGrantedAuthority("ROLE_" + u.perfil)));
        this.id = u.id;
        this.nome = u.nome;
    }
}
