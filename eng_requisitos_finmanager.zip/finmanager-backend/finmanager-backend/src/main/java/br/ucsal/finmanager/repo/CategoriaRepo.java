package br.ucsal.finmanager.repo;

import br.ucsal.finmanager.model.*;
import java.util.*;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CategoriaRepo extends JpaRepository<Categoria, Long> {
    List<Categoria> findByUsuarioId(Long u);
    Optional<Categoria> findByIdAndUsuarioId(Long id, Long u);
}
