package br.ucsal.finmanager.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import java.math.BigDecimal;
import java.time.LocalDate;

@Entity
@Table(name = "transacao")
public class Transacao {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY) public Long id;
    @Column(name = "descricao", nullable = false) public String desc;
    @Column(precision = 15, scale = 2, nullable = false) public BigDecimal valor;
    @Column(name = "data_lancamento", nullable = false) public LocalDate data;
    /** Receita | Despesa */
    @Column(nullable = false) public String tipo;
    @Column(name = "forma_pagamento") public String forma;
    @Column(name = "categoria_id") public Long cat;
    @Column(name = "conta_id", nullable = false) public Long conta;
    /** Pendente | Efetivada */
    @Column(nullable = false) public String status = "Efetivada";
    @Column(name = "comprovante") public String comp;
    @JsonIgnore @Column(name = "usuario_id", nullable = false) public Long usuarioId;
}
