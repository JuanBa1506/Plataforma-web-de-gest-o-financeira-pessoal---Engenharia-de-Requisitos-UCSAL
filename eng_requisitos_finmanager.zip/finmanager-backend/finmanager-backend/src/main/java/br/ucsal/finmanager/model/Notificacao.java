package br.ucsal.finmanager.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import java.math.BigDecimal;
import java.time.LocalDate;

@Entity
@Table(name = "notificacao")
public class Notificacao {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY) public Long id;
    @Column(name = "texto", nullable = false) public String t;
    @Column(name = "data_envio") public LocalDate d = LocalDate.now();
    public boolean lida;
    @JsonIgnore @Column(name = "usuario_id", nullable = false) public Long usuarioId;

    public static Notificacao de(Long usuarioId, String texto) {
        Notificacao n = new Notificacao();
        n.usuarioId = usuarioId;
        n.t = texto;
        return n;
    }
}
