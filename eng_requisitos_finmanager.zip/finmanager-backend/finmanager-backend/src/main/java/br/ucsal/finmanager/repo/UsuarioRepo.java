package br.ucsal.finmanager.repo;

import br.ucsal.finmanager.model.*;
import java.util.*;
import org.springframework.data.jpa.repository.JpaRepository;

public interface UsuarioRepo extends JpaRepository<Usuario, Long> {
    Optional<Usuario> findByEmail(String email);
    boolean existsByEmail(String email);
}
