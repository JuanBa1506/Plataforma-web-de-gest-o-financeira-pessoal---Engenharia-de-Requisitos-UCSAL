package br.ucsal.finmanager.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import java.math.BigDecimal;
import java.time.LocalDate;

@Entity
@Table(name = "meta")
public class Meta {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY) public Long id;
    @Column(nullable = false) public String nome;
    @Column(name = "valor_alvo", precision = 15, scale = 2, nullable = false) public BigDecimal alvo;
    @Column(name = "valor_acumulado", precision = 15, scale = 2, nullable = false) public BigDecimal acum = BigDecimal.ZERO;
    @Column(name = "aporte_mensal", precision = 15, scale = 2) public BigDecimal aporte;
    @Column(name = "data_pretendida") public LocalDate fim;
    @JsonIgnore @Column(name = "usuario_id", nullable = false) public Long usuarioId;
}
