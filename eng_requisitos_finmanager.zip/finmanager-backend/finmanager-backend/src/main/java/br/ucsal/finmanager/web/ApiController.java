package br.ucsal.finmanager.web;

import br.ucsal.finmanager.config.Logado;
import br.ucsal.finmanager.model.*;
import br.ucsal.finmanager.service.FinService;
import java.math.BigDecimal;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.springframework.http.HttpStatus;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api")
public class ApiController {
    public record Valor(BigDecimal valor) {}

    private final FinService s;

    public ApiController(FinService s) { this.s = s; }

    private static Map<String, Object> alerta(String msg) {
        Map<String, Object> m = new HashMap<>();
        m.put("alerta", msg);
        return m;
    }

    @GetMapping("/state")
    public FinService.Estado estado(@AuthenticationPrincipal Logado me) { return s.estado(me.id); }

    /* contas */
    @PostMapping("/contas") @ResponseStatus(HttpStatus.CREATED)
    public Conta criarConta(@AuthenticationPrincipal Logado me, @RequestBody Conta c) { return s.criarConta(me.id, c); }
    @DeleteMapping("/contas/{id}") @ResponseStatus(HttpStatus.NO_CONTENT)
    public void removerConta(@AuthenticationPrincipal Logado me, @PathVariable Long id) { s.removerConta(me.id, id); }

    /* categorias */
    @PostMapping("/categorias") @ResponseStatus(HttpStatus.CREATED)
    public Categoria criarCategoria(@AuthenticationPrincipal Logado me, @RequestBody Categoria c) { return s.criarCategoria(me.id, c); }
    @DeleteMapping("/categorias/{id}") @ResponseStatus(HttpStatus.NO_CONTENT)
    public void removerCategoria(@AuthenticationPrincipal Logado me, @PathVariable Long id) { s.removerCategoria(me.id, id); }

    /* transações */
    @PostMapping("/transacoes") @ResponseStatus(HttpStatus.CREATED)
    public Map<String, Object> criarTransacao(@AuthenticationPrincipal Logado me, @RequestBody Transacao t) {
        return alerta(s.criarTransacao(me.id, t));
    }
    @PostMapping("/transacoes/lote") @ResponseStatus(HttpStatus.CREATED)
    public Map<String, Object> importar(@AuthenticationPrincipal Logado me, @RequestBody List<Transacao> itens) {
        return Map.of("importadas", s.importar(me.id, itens));
    }
    @PostMapping("/transacoes/{id}/confirmar")
    public Map<String, Object> confirmar(@AuthenticationPrincipal Logado me, @PathVariable Long id) {
        return alerta(s.confirmar(me.id, id));
    }
    @DeleteMapping("/transacoes/{id}") @ResponseStatus(HttpStatus.NO_CONTENT)
    public void removerTransacao(@AuthenticationPrincipal Logado me, @PathVariable Long id) { s.removerTransacao(me.id, id); }

    /* limites orçamentários */
    @PutMapping("/limites")
    public Limite definirLimite(@AuthenticationPrincipal Logado me, @RequestBody Limite l) { return s.definirLimite(me.id, l); }
    @DeleteMapping("/limites/{cat}") @ResponseStatus(HttpStatus.NO_CONTENT)
    public void removerLimite(@AuthenticationPrincipal Logado me, @PathVariable Long cat) { s.removerLimite(me.id, cat); }

    /* metas */
    @PostMapping("/metas") @ResponseStatus(HttpStatus.CREATED)
    public Meta criarMeta(@AuthenticationPrincipal Logado me, @RequestBody Meta m) { return s.criarMeta(me.id, m); }
    @PostMapping("/metas/{id}/aporte")
    public Meta aportar(@AuthenticationPrincipal Logado me, @PathVariable Long id, @RequestBody Valor v) { return s.aportar(me.id, id, v.valor()); }
    @DeleteMapping("/metas/{id}") @ResponseStatus(HttpStatus.NO_CONTENT)
    public void removerMeta(@AuthenticationPrincipal Logado me, @PathVariable Long id) { s.removerMeta(me.id, id); }

    /* recorrências */
    @PostMapping("/agendamentos") @ResponseStatus(HttpStatus.CREATED)
    public Agendamento criarAgendamento(@AuthenticationPrincipal Logado me, @RequestBody Agendamento a) { return s.criarAgendamento(me.id, a); }
    @PostMapping("/agendamentos/processar")
    public Map<String, Object> processar(@AuthenticationPrincipal Logado me) { return Map.of("geradas", s.processar(me.id)); }
    @DeleteMapping("/agendamentos/{id}") @ResponseStatus(HttpStatus.NO_CONTENT)
    public void removerAgendamento(@AuthenticationPrincipal Logado me, @PathVariable Long id) { s.removerAgendamento(me.id, id); }

    /* notificações */
    @PostMapping("/notificacoes/lidas") @ResponseStatus(HttpStatus.NO_CONTENT)
    public void lidas(@AuthenticationPrincipal Logado me) { s.marcarLidas(me.id); }
    @DeleteMapping("/notificacoes") @ResponseStatus(HttpStatus.NO_CONTENT)
    public void limpar(@AuthenticationPrincipal Logado me) { s.limparNotificacoes(me.id); }
    @DeleteMapping("/notificacoes/{id}") @ResponseStatus(HttpStatus.NO_CONTENT)
    public void removerNotificacao(@AuthenticationPrincipal Logado me, @PathVariable Long id) { s.removerNotificacao(me.id, id); }
}
