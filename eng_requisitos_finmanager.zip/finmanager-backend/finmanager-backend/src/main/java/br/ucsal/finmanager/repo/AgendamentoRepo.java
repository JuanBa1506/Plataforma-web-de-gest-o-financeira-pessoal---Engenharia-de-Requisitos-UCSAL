package br.ucsal.finmanager.repo;

import br.ucsal.finmanager.model.*;
import java.util.*;
import org.springframework.data.jpa.repository.JpaRepository;

import java.time.LocalDate;

public interface AgendamentoRepo extends JpaRepository<Agendamento, Long> {
    List<Agendamento> findByUsuarioId(Long u);
    Optional<Agendamento> findByIdAndUsuarioId(Long id, Long u);
    List<Agendamento> findByProxLessThanEqual(LocalDate d);
    List<Agendamento> findByProx(LocalDate d);
    void deleteByContaAndUsuarioId(Long conta, Long u);
}
