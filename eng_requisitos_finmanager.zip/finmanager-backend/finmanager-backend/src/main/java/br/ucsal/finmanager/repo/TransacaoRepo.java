package br.ucsal.finmanager.repo;

import br.ucsal.finmanager.model.Transacao;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.*;
import org.springframework.data.jpa.repository.*;
import org.springframework.data.repository.query.Param;

public interface TransacaoRepo extends JpaRepository<Transacao, Long> {
    List<Transacao> findByUsuarioId(Long u);
    Optional<Transacao> findByIdAndUsuarioId(Long id, Long u);
    void deleteByContaAndUsuarioId(Long conta, Long u);

    @Query("select coalesce(sum(t.valor), 0) from Transacao t where t.usuarioId = :u and t.tipo = 'Despesa' "
         + "and t.status = 'Efetivada' and t.cat in :cats and t.data >= :ini and t.data <= :fim")
    BigDecimal gasto(@Param("u") Long u, @Param("cats") Collection<Long> cats,
                     @Param("ini") LocalDate ini, @Param("fim") LocalDate fim);
}
