package br.ucsal.finmanager.repo;

import br.ucsal.finmanager.model.*;
import java.util.*;
import org.springframework.data.jpa.repository.JpaRepository;

public interface MetaRepo extends JpaRepository<Meta, Long> {
    List<Meta> findByUsuarioId(Long u);
    Optional<Meta> findByIdAndUsuarioId(Long id, Long u);
}
