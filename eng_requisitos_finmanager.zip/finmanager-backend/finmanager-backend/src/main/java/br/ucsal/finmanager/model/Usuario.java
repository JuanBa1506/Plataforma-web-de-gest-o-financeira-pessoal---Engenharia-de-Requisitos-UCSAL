package br.ucsal.finmanager.model;

import jakarta.persistence.*;

@Entity
@Table(name = "usuario")
public class Usuario {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY) public Long id;
    @Column(nullable = false) public String nome;
    @Column(nullable = false, unique = true) public String email;
    @Column(name = "senha_hash", nullable = false) public String senhaHash;
    /** USER (usuário comum) ou ADMIN (administrador do sistema). */
    @Column(nullable = false) public String perfil = "USER";
}
