package br.ucsal.finmanager.web;

import br.ucsal.finmanager.config.Logado;
import br.ucsal.finmanager.model.Usuario;
import br.ucsal.finmanager.service.FinService;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.util.Map;
import org.springframework.http.HttpStatus;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.web.context.HttpSessionSecurityContextRepository;
import org.springframework.security.web.context.SecurityContextRepository;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/auth")
public class AuthController {
    public record Cadastro(String nome, String email, String senha) {}
    public record Login(String email, String senha) {}

    private final AuthenticationManager manager;
    private final FinService service;
    private final SecurityContextRepository repo = new HttpSessionSecurityContextRepository();

    public AuthController(AuthenticationManager manager, FinService service) {
        this.manager = manager;
        this.service = service;
    }

    @PostMapping("/register")
    @ResponseStatus(HttpStatus.CREATED)
    public Map<String, Object> register(@RequestBody Cadastro c) {
        Usuario u = service.registrar(c.nome(), c.email(), c.senha());
        return Map.of("id", u.id, "nome", u.nome, "email", u.email);
    }

    @PostMapping("/login")
    public Map<String, Object> login(@RequestBody Login l, HttpServletRequest rq, HttpServletResponse rs) {
        String email = l.email() == null ? "" : l.email().trim().toLowerCase();
        String senha = l.senha() == null ? "" : l.senha();
        Authentication auth = manager.authenticate(UsernamePasswordAuthenticationToken.unauthenticated(email, senha));
        SecurityContext ctx = SecurityContextHolder.createEmptyContext();
        ctx.setAuthentication(auth);
        SecurityContextHolder.setContext(ctx);
        repo.saveContext(ctx, rq, rs);
        Logado me = (Logado) auth.getPrincipal();
        return Map.of("nome", me.nome, "email", me.getUsername());
    }

    @GetMapping("/me")
    public Map<String, Object> me(@AuthenticationPrincipal Logado me) {
        return Map.of("nome", me.nome, "email", me.getUsername());
    }

    @PostMapping("/logout")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void logout(HttpServletRequest rq) {
        var sessao = rq.getSession(false);
        if (sessao != null) sessao.invalidate();
        SecurityContextHolder.clearContext();
    }

    /** O envio real de e-mail depende de SMTP; aqui a resposta é sempre neutra por segurança. */
    @PostMapping("/recuperar")
    @ResponseStatus(HttpStatus.ACCEPTED)
    public Map<String, String> recuperar(@RequestBody Map<String, String> corpo) {
        return Map.of("mensagem", "Se o e-mail existir, enviaremos o link de redefinição.");
    }
}
