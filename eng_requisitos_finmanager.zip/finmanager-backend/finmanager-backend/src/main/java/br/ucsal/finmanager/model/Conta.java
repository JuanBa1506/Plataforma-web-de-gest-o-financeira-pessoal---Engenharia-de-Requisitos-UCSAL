package br.ucsal.finmanager.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import java.math.BigDecimal;
import java.time.LocalDate;

@Entity
@Table(name = "conta")
public class Conta {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY) public Long id;
    @Column(nullable = false) public String nome;
    public String tipo;
    @Column(name = "saldo_inicial", precision = 15, scale = 2) public BigDecimal ini = BigDecimal.ZERO;
    @JsonIgnore @Column(name = "usuario_id", nullable = false) public Long usuarioId;
}
