package br.ucsal.finmanager.repo;

import br.ucsal.finmanager.model.*;
import java.util.*;
import org.springframework.data.jpa.repository.JpaRepository;

public interface LimiteRepo extends JpaRepository<Limite, Long> {
    List<Limite> findByUsuarioId(Long u);
    Optional<Limite> findByCatAndUsuarioId(Long cat, Long u);
    void deleteByCatInAndUsuarioId(Collection<Long> cats, Long u);
}
