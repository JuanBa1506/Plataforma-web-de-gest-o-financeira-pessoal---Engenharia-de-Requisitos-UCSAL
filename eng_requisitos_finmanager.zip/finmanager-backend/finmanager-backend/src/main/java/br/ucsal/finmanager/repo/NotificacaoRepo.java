package br.ucsal.finmanager.repo;

import br.ucsal.finmanager.model.*;
import java.util.*;
import org.springframework.data.jpa.repository.JpaRepository;

public interface NotificacaoRepo extends JpaRepository<Notificacao, Long> {
    List<Notificacao> findByUsuarioIdOrderByIdDesc(Long u);
    Optional<Notificacao> findByIdAndUsuarioId(Long id, Long u);
    void deleteByUsuarioId(Long u);
}
