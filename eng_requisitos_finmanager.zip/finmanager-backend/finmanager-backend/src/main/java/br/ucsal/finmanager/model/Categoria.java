package br.ucsal.finmanager.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import java.math.BigDecimal;
import java.time.LocalDate;

@Entity
@Table(name = "categoria")
public class Categoria {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY) public Long id;
    @Column(nullable = false) public String nome;
    @Column(name = "categoria_pai_id") public Long pai;
    @JsonIgnore @Column(name = "usuario_id", nullable = false) public Long usuarioId;
}
