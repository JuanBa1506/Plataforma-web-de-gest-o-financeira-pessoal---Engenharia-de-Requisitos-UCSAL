'use strict';
const $=s=>document.querySelector(s);
const R=v=>v.toLocaleString('pt-BR',{style:'currency',currency:'BRL'});
const D=d=>d.split('-').reverse().join('/');
const esc=s=>String(s).replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
const today=new Date().toISOString().slice(0,10),ym=today.slice(0,7);
const COL=['#356AE6','#35C6B0','#D9B66F','#68758A','#6B8FEA','#1A9C88'];
const IC={dashboard:'M3 12l9-9 9 9M5 10v10h14V10',transacoes:'M4 7h16M4 12h16M4 17h10',contas:'M3 7h18v12H3zM3 7l3-3h12l3 3M16 13h2',categorias:'M4 4h8l8 8-8 8-8-8z',orcamentos:'M12 3a9 9 0 100 18 9 9 0 000-18zM12 3v9h9',metas:'M5 21V4M5 4h12l-2 4 2 4H5',agendamentos:'M4 12a8 8 0 0114-5l2 2M20 4v5h-5M20 12a8 8 0 01-14 5l-2-2M4 20v-5h5',importar:'M12 3v12M7 10l5 5 5-5M4 21h16',relatorios:'M4 20V10M10 20V4M16 20v-8M22 20H2',notificacoes:'M6 9a6 6 0 0112 0c0 6 3 7 3 7H3s3-1 3-7M10 20a2 2 0 004 0',lixo:'M4 7h16M10 11v6M14 11v6M6 7l1 13h10l1-13M9 7V4h6v3',sair:'M9 4H4v16h5M16 8l4 4-4 4M20 12H9'};
const ico=k=>`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="${IC[k]}"/></svg>`;
const NAV=[['dashboard','Painel'],['transacoes','Transações'],['contas','Contas'],['categorias','Categorias'],['orcamentos','Orçamentos'],['metas','Metas'],['agendamentos','Recorrências'],['importar','Importar extrato'],['relatorios','Relatórios'],['notificacoes','Notificações']];
let uid=100,last=Date.now();
const S={user:null,view:'dashboard',auth:'login',tmp:null,filtro:'',imp:null,
contas:[{id:1,nome:'Nubank',tipo:'Conta corrente',ini:2500},{id:2,nome:'Carteira',tipo:'Carteira física',ini:150}],
cats:[{id:1,nome:'Moradia',pai:null},{id:2,nome:'Aluguel',pai:1},{id:3,nome:'Alimentação',pai:null},{id:4,nome:'Mercado',pai:3},{id:5,nome:'Transporte',pai:null},{id:6,nome:'Lazer',pai:null},{id:7,nome:'Salário',pai:null}],
tx:[{id:1,desc:'Salário',valor:3800,data:ym+'-01',tipo:'Receita',forma:'Transferência',cat:7,conta:1,status:'Efetivada'},
{id:2,desc:'Aluguel',valor:1200,data:ym+'-02',tipo:'Despesa',forma:'Boleto',cat:2,conta:1,status:'Efetivada'},
{id:3,desc:'Supermercado',valor:620,data:ym+'-03',tipo:'Despesa',forma:'Cartão de débito',cat:4,conta:1,status:'Efetivada'},
{id:4,desc:'Cinema',valor:90,data:ym+'-04',tipo:'Despesa',forma:'Pix',cat:6,conta:2,status:'Efetivada'},
{id:5,desc:'Ônibus e app',valor:130,data:ym+'-05',tipo:'Despesa',forma:'Pix',cat:5,conta:1,status:'Efetivada'}],
lim:[{cat:3,teto:900,pct:80},{cat:6,teto:300,pct:80}],
metas:[{id:1,nome:'Reserva de emergência',alvo:6000,acum:1800,aporte:300,fim:'2027-06-30'}],
ag:[{id:1,desc:'Aluguel',valor:1200,per:'Mensal',prox:ym+'-10',cat:2,conta:1,tipo:'Despesa'}],
notifs:[{id:1,t:'Aluguel vence em 3 dias (e-mail e push).',d:today,lida:false}]};

/* helpers de domínio */
const cat=id=>S.cats.find(c=>c.id==id);
const nivel=c=>c.pai?nivel(cat(c.pai))+1:1;
const desc=id=>{let r=[id];S.cats.filter(c=>c.pai===id).forEach(c=>r.push(...desc(c.id)));return r};
const flat=(p=null,n=1)=>S.cats.filter(c=>c.pai===p).flatMap(c=>[{...c,n},...flat(c.id,n+1)]);
const catOpts=(nul)=>(nul?'<option value="">Sem categoria</option>':'')+flat().map(c=>`<option value="${c.id}">${'– '.repeat(c.n-1)+esc(c.nome)}</option>`).join('');
const catName=id=>id?esc(cat(id).nome):'Sem categoria';
const saldo=c=>c.ini+S.tx.filter(t=>t.conta==c.id&&t.status==='Efetivada').reduce((a,t)=>a+(t.tipo==='Receita'?t.valor:-t.valor),0);
const mtx=()=>S.tx.filter(t=>t.status==='Efetivada'&&t.data.startsWith(ym));
const gasto=id=>mtx().filter(t=>t.tipo==='Despesa'&&desc(id).includes(+t.cat)).reduce((a,t)=>a+t.valor,0);
const porCat=()=>S.cats.filter(c=>!c.pai).map(c=>({n:c.nome,v:gasto(c.id)})).filter(x=>x.v>0).sort((a,b)=>b.v-a.v);
const notif=t=>{S.notifs.unshift({id:++uid,t,d:today,lida:false});badge()};
function toast(m){const t=$('#toast');t.textContent=m;t.classList.add('on');clearTimeout(toast.h);toast.h=setTimeout(()=>t.classList.remove('on'),3500)}

/* componentes */
const fld=(n,l,t='text',x='')=>`<label>${l}<input name="${n}" type="${t}" ${x}></label>`;
const sel=(n,l,o)=>`<label>${l}<select name="${n}">${o}</select></label>`;
const opts=a=>a.map(o=>`<option>${o}</option>`).join('');
const contaOpts=()=>S.contas.map(c=>`<option value="${c.id}">${esc(c.nome)}</option>`).join('');
const del=(t,id)=>`<button class="btn sec sm del" data-act="del" data-t="${t}" data-id="${id}" aria-label="Remover" title="Remover">${ico('lixo')}</button>`;
const num=v=>`<span class="num" data-n="${v}">${R(0)}</span>`;
const bar=(p,w)=>`<div class="bar ${p>=100?'over':p>=w?'warn':''}" role="progressbar" aria-valuenow="${Math.round(p)}" aria-valuemin="0" aria-valuemax="100"><i data-w="${Math.min(p,100)}"></i></div>`;
function donut(it){const T=it.reduce((a,x)=>a+x.v,0);if(!T)return '<p class="mut">Sem despesas neste mês.</p>';let acc=0;
const c=it.map((x,i)=>{const p=x.v/T*100,s=`<circle r="15.9155" cx="21" cy="21" fill="none" stroke="${COL[i%6]}" stroke-width="6" stroke-dasharray="0 100" data-d="${p} ${100-p}" stroke-dashoffset="${-acc}"/>`;acc+=p;return s}).join('');
return `<div class="donut"><svg viewBox="0 0 42 42" width="160" height="160" role="img" aria-label="Despesas por categoria"><circle r="15.9155" cx="21" cy="21" fill="none" stroke="var(--soft)" stroke-width="6"/>${c}</svg><ul class="leg">${it.map((x,i)=>`<li><i style="background:${COL[i%6]}"></i>${esc(x.n)} <b class="num">${R(x.v)}</b></li>`).join('')}</ul></div>`}

/* telas */
const V={
dashboard(){const rec=mtx().filter(t=>t.tipo==='Receita').reduce((a,t)=>a+t.valor,0),des=mtx().filter(t=>t.tipo==='Despesa').reduce((a,t)=>a+t.valor,0),tot=S.contas.reduce((a,c)=>a+saldo(c),0);
return `<div class="grid"><div class="card hero"><h3>Patrimônio consolidado</h3><div class="big">${num(tot)}</div><p class="mut">Atualizado a cada lançamento.</p></div>
<div class="card"><h3>Mês atual</h3><div class="kv"><span>Receitas</span><b class="pos">${num(rec)}</b></div><div class="kv"><span>Despesas</span><b class="neg">${num(des)}</b></div><div class="kv"><span>Resultado</span><b>${num(rec-des)}</b></div></div>
<div class="card"><h3>Despesas por categoria</h3>${donut(porCat())}</div>
<div class="card"><h3>Limites do mês</h3>${S.lim.map(l=>{const g=gasto(l.cat),p=g/l.teto*100;return `<div class="item"><div class="row sb"><b>${catName(l.cat)}</b><span class="num mut">${R(g)} / ${R(l.teto)}</span></div>${bar(p,l.pct)}${p>=l.pct?`<small class="${p>=100?'neg':'mut'}">${p>=100?'Limite ultrapassado':'Acima de '+l.pct+'% do limite'}</small>`:''}</div>`}).join('')||'<p class="mut">Nenhum limite definido.</p>'}</div>
<div class="card"><h3>Metas</h3>${S.metas.map(m=>`<div class="item"><div class="row sb"><b>${esc(m.nome)}</b><span class="num">${Math.round(m.acum/m.alvo*100)}%</span></div>${bar(m.acum/m.alvo*100,101)}</div>`).join('')||'<p class="mut">Nenhuma meta criada.</p>'}</div>
<div class="card"><h3>Próximos vencimentos</h3>${S.ag.map(a=>`<div class="item row sb"><span>${esc(a.desc)}<br><small class="mut">${D(a.prox)} · ${a.per}</small></span><b class="num">${R(a.valor)}</b></div>`).join('')||'<p class="mut">Sem recorrências.</p>'}</div></div>`},
transacoes(){const l=S.tx.filter(t=>!S.filtro||t.tipo===S.filtro).sort((a,b)=>b.data.localeCompare(a.data));
return `<div class="card"><div class="row sb noprint" style="margin-bottom:14px"><select data-chg="filtro" style="width:auto;margin:0" aria-label="Filtrar por tipo"><option value="">Todos os tipos</option><option ${S.filtro==='Receita'?'selected':''}>Receita</option><option ${S.filtro==='Despesa'?'selected':''}>Despesa</option></select><button class="btn" data-act="nova-tx">Nova transação</button></div><div class="tw"><table><thead><tr><th>Data</th><th>Descrição</th><th>Categoria</th><th>Conta</th><th>Pagamento</th><th>Status</th><th class="r">Valor</th><th></th></tr></thead><tbody>${l.map(t=>`<tr><td>${D(t.data)}</td><td>${esc(t.desc)}${t.comp?' 📎':''}</td><td>${catName(t.cat)}</td><td>${esc(S.contas.find(c=>c.id==t.conta).nome)}</td><td>${esc(t.forma)}</td><td><span class="tag ${t.status}">${t.status}</span></td><td class="r num ${t.tipo==='Receita'?'pos':'neg'}">${t.tipo==='Receita'?'+':'−'}${R(t.valor)}</td><td class="r">${del('tx',t.id)}</td></tr>`).join('')}</tbody></table></div></div>`},
contas(){return `<div class="card"><div class="row sb" style="margin-bottom:8px"><h3>Contas e carteiras</h3><button class="btn" data-act="nova-conta">Adicionar conta</button></div>${S.contas.map(c=>`<div class="item row sb"><span><b>${esc(c.nome)}</b><br><small class="mut">${c.tipo}</small></span><span class="row"><b class="num">${num(saldo(c))}</b>${del('conta',c.id)}</span></div>`).join('')}</div>`},
categorias(){const t=p=>{const f=S.cats.filter(c=>c.pai===p);return f.length?`<ul class="tree ${p?'':'root'}">${f.map(c=>`<li><span>${esc(c.nome)}${del('cat',c.id)}</span>${t(c.id)}</li>`).join('')}</ul>`:''};
return `<div class="card"><div class="row sb" style="margin-bottom:8px"><h3>Categorias</h3><button class="btn" data-act="nova-cat">Nova categoria</button></div><p class="mut">Organize em até 3 níveis.</p>${t(null)}</div>`},
orcamentos(){return `<div class="card"><div class="row sb" style="margin-bottom:8px"><h3>Limites mensais por categoria</h3><button class="btn" data-act="nova-lim">Definir limite</button></div>${S.lim.map(l=>{const g=gasto(l.cat),p=g/l.teto*100;return `<div class="item"><div class="row sb"><b>${catName(l.cat)}</b><span class="row"><span class="num mut">${R(g)} de ${R(l.teto)} · alerta em ${l.pct}%</span>${del('lim',l.cat)}</span></div>${bar(p,l.pct)}</div>`}).join('')||'<p class="mut">Defina um limite para receber alertas no painel.</p>'}</div>`},
metas(){return `<div class="row noprint" style="justify-content:flex-end;margin-bottom:16px"><button class="btn" data-act="nova-meta">Nova meta</button></div><div class="grid">${S.metas.map(m=>{const p=m.acum/m.alvo*100;return `<div class="card"><h3>${esc(m.nome)}</h3><div class="big">${Math.round(p)}%</div>${bar(p,101)}<p class="num">${R(m.acum)} de ${R(m.alvo)}</p><p class="mut">Aporte mensal ${R(m.aporte)} · até ${D(m.fim)}</p><div class="row"><button class="btn sec sm" data-act="aportar" data-id="${m.id}">Registrar aporte</button>${del('meta',m.id)}</div></div>`}).join('')}</div>`},
agendamentos(){const p=S.tx.filter(t=>t.status==='Pendente');
return `<div class="grid"><div class="card"><div class="row sb" style="margin-bottom:8px"><h3>Lançamentos recorrentes</h3><button class="btn" data-act="nova-ag">Agendar</button></div>${S.ag.map(a=>`<div class="item row sb"><span>${esc(a.desc)}<br><small class="mut">${a.per} · próximo em ${D(a.prox)}</small></span><span class="row"><b class="num">${R(a.valor)}</b>${del('ag',a.id)}</span></div>`).join('')}<button class="btn sec sm" data-act="venc" style="margin-top:12px">Processar vencimentos agora</button></div>
<div class="card"><h3>Pendências para confirmar</h3>${p.map(t=>`<div class="item row sb"><span>${esc(t.desc)}<br><small class="mut">${D(t.data)} · ${R(t.valor)}</small></span><span class="row"><button class="btn sm" data-act="conf" data-id="${t.id}">Confirmar</button><button class="btn sec sm" data-act="desc" data-id="${t.id}">Descartar</button></span></div>`).join('')||'<p class="mut">Nada pendente.</p>'}</div></div>`},
importar(){const i=S.imp;return `<div class="card"><h3>Importar extrato (.csv ou .ofx)</h3><label>Arquivo<input type="file" accept=".csv,.ofx" data-chg="arq"></label><button class="btn sec sm" data-act="imp-demo">Usar extrato de exemplo</button>
${i?`<h3 style="margin:24px 0 10px">Conferência antes de gravar</h3><div class="tw"><table><thead><tr><th></th><th>Data</th><th>Descrição</th><th class="r">Valor</th><th>Situação</th></tr></thead><tbody>${i.map((x,k)=>`<tr><td><input type="checkbox" data-chk="${k}" ${x.sel?'checked':''} style="width:auto;margin:0" aria-label="Incluir lançamento"></td><td>${D(x.data)}</td><td>${esc(x.desc)}</td><td class="r num">${R(x.valor)}</td><td>${x.dup?'<span class="tag Pendente">Possível duplicidade</span>':'<span class="tag">Novo</span>'}</td></tr>`).join('')}</tbody></table></div><button class="btn" data-act="imp-conf" style="margin-top:14px">Gravar selecionados</button>`:''}</div>`},
relatorios(){const rows=porCat(),max=Math.max(1,...rows.map(r=>r.v));
return `<div class="row noprint" style="justify-content:flex-end;margin-bottom:16px"><button class="btn sec" data-act="xlsx">Exportar XLSX</button><button class="btn" data-act="pdf">Exportar PDF</button></div><div class="grid"><div class="card"><h3>Distribuição de despesas</h3>${donut(rows)}</div><div class="card"><h3>Despesas por categoria</h3>${rows.map((r,i)=>`<div class="item"><div class="row sb"><span>${esc(r.n)}</span><b class="num">${R(r.v)}</b></div><div class="bar"><i data-w="${r.v/max*100}" style="background:${COL[i%6]}"></i></div></div>`).join('')||'<p class="mut">Sem dados.</p>'}</div></div>`},
notificacoes(){return `<div class="card"><div class="row sb" style="margin-bottom:8px"><h3>Notificações</h3>${S.notifs.length?'<button class="btn sec sm" data-act="limpar-not">Limpar todas</button>':''}</div>${S.notifs.map(n=>`<div class="item row sb"><span>${esc(n.t)}<br><small class="mut">${D(n.d)}</small></span>${del('not',n.id)}</div>`).join('')||'<p class="mut">Nenhuma notificação.</p>'}</div>`}
};

/* animações pós-render */
function animate(root,stagger){
 if(stagger)root.querySelectorAll('.grid>.card,#view>.card').forEach((e,i)=>{e.classList.add('rv');e.style.setProperty('--i',i)});
 requestAnimationFrame(()=>requestAnimationFrame(()=>{
  root.querySelectorAll('[data-w]').forEach(b=>b.style.width=b.dataset.w+'%');
  root.querySelectorAll('[data-d]').forEach(c=>c.setAttribute('stroke-dasharray',c.dataset.d));
 }));
 root.querySelectorAll('[data-n]').forEach(el=>{const to=+el.dataset.n,t0=performance.now();
  const f=t=>{const k=Math.min(1,(t-t0)/900),e=1-Math.pow(1-k,3);el.textContent=R(to*e);if(k<1)requestAnimationFrame(f)};requestAnimationFrame(f)});
}

/* renderização */
function authView(){const a=S.auth,T=(k,l)=>`<button role="tab" aria-selected="${a===k}" data-auth="${k}">${l}</button>`;let f='';
if(a==='login')f=`<form data-f="login">${fld('email','E-mail','email','required autocomplete="username"')}${fld('senha','Senha','password','required autocomplete="current-password"')}<button class="btn" style="width:100%">Entrar</button><p><button type="button" class="lnk" data-auth="rec">Esqueci minha senha</button></p></form>`;
if(a==='cad')f=`<form data-f="cad">${fld('nome','Nome completo','text','required')}${fld('email','E-mail','email','required')}${fld('senha','Senha (mínimo 8 caracteres)','password','required minlength="8"')}<button class="btn" style="width:100%">Criar conta</button></form>`;
if(a==='rec')f=`<form data-f="rec"><p class="mut">Enviaremos um link de redefinição para o seu e-mail.</p>${fld('email','E-mail','email','required')}<button class="btn" style="width:100%">Enviar link</button><p><button type="button" class="lnk" data-auth="login">Voltar ao login</button></p></form>`;
const head={login:'Bem-vindo de volta',cad:'Crie sua conta',rec:'Recuperar senha'}[a];
return `<div class="auth"><section class="brand"><div class="logo" style="padding:0"><b>F</b>FinManager</div><div><h1>Suas finanças pessoais, claras e sob controle.</h1><ul><li>Saldo consolidado em tempo real</li><li>Limites por categoria com alertas</li><li>Metas, recorrências e relatórios</li></ul></div><small style="opacity:.7">UCSAL · Engenharia de Requisitos</small></section><section class="fw"><div class="form" id="fm"><h2>${head}</h2>${a==='rec'?'':`<div class="tabs" role="tablist">${T('login','Entrar')}${T('cad','Criar conta')}</div>`}${f}</div></section></div>`}
function render(){const A=$('#app');if(!S.user){A.innerHTML=authView();return}
A.innerHTML=`<div class="shell"><nav aria-label="Principal"><div class="logo"><b>F</b>FinManager</div>${NAV.map(([k,l])=>`<a href="#${k}" data-nav="${k}">${ico(k)}${l}${k==='notificacoes'?'<span class="bdg" hidden></span>':''}</a>`).join('')}<div class="usr">${esc(S.user.email)}<br><button class="lnk" style="color:#fff;margin-top:6px;display:flex;gap:8px;align-items:center" data-act="logout">${ico('sair').replace('<svg','<svg width="16" height="16"')}Sair</button></div></nav><main><div class="top"><div><h1 id="ttl"></h1><small class="mut">Olá, ${esc(S.user.nome)}</small></div><span class="chip num noprint" id="tm"></span></div><div id="view"></div></main></div>`;badge();view(true)}
function view(anim){const v=$('#view');if(!v)return;const k=S.view;
 document.querySelectorAll('[data-nav]').forEach(a=>{const on=a.dataset.nav===k;on?a.setAttribute('aria-current','page'):a.removeAttribute('aria-current')});
 $('#ttl').textContent=NAV.find(n=>n[0]===k)[1];
 v.innerHTML=V[k]();
 if(anim){v.classList.remove('in');void v.offsetWidth;v.classList.add('in')}
 animate(v,anim);
}
function badge(){const b=$('.bdg');if(!b)return;const n=S.notifs.filter(x=>!x.lida).length;b.hidden=!n;b.textContent=n}
function go(){const h=location.hash.slice(1);if(V[h])S.view=h;if(h==='notificacoes')S.notifs.forEach(n=>n.lida=true);S.user&&view(true);badge()}
addEventListener('hashchange',go);

/* sessão (RN01: 15 min) */
function tick(){if(!S.user)return;const r=15*60-Math.floor((Date.now()-last)/1000);
 if(r<=0){S.user=null;S.auth='login';render();toast('Sessão encerrada após 15 minutos sem atividade.');return}
 const e=$('#tm');if(e)e.textContent='Sessão expira em '+String(Math.floor(r/60)).padStart(2,'0')+':'+String(r%60).padStart(2,'0')}
setInterval(tick,1000);
['mousemove','keydown','touchstart','click'].forEach(ev=>addEventListener(ev,()=>last=Date.now(),{passive:true}));

/* modal */
const DEL={
tx:{n:'esta transação',f:id=>S.tx=S.tx.filter(t=>t.id!=id)},
conta:{n:'esta conta e todas as transações e recorrências dela',chk:()=>S.contas.length>1||'Mantenha ao menos uma conta.',f:id=>{S.contas=S.contas.filter(c=>c.id!=id);S.tx=S.tx.filter(t=>t.conta!=id);S.ag=S.ag.filter(g=>g.conta!=id)}},
cat:{n:'esta categoria e suas subcategorias (as transações ficam sem categoria)',f:id=>{const ids=desc(+id);S.cats=S.cats.filter(c=>!ids.includes(c.id));S.tx.forEach(t=>{if(ids.includes(+t.cat))t.cat=null});S.ag.forEach(g=>{if(ids.includes(+g.cat))g.cat=null});S.lim=S.lim.filter(l=>!ids.includes(l.cat))}},
lim:{n:'este limite',f:id=>S.lim=S.lim.filter(l=>l.cat!=id)},
meta:{n:'esta meta',f:id=>S.metas=S.metas.filter(m=>m.id!=id)},
ag:{n:'esta recorrência',f:id=>S.ag=S.ag.filter(g=>g.id!=id)},
not:{n:'esta notificação',f:id=>S.notifs=S.notifs.filter(n=>n.id!=id)}};
function modal(t,body,f,ok='Salvar',cls=''){const o=document.createElement('div');o.className='ov';o.innerHTML=`<div class="md" role="dialog" aria-modal="true" aria-label="${t}"><h2>${t}</h2><form data-f="${f}">${body}<div class="row" style="justify-content:flex-end"><button type="button" class="btn sec" data-act="x">Cancelar</button><button class="btn ${cls}">${ok}</button></div></form></div>`;document.body.appendChild(o);const i=o.querySelector('input,select');i&&i.focus()}
function close(){document.querySelectorAll('.ov:not(.out)').forEach(o=>{o.classList.add('out');setTimeout(()=>o.remove(),200)})}
addEventListener('keydown',e=>{if(e.key==='Escape')close()});
document.addEventListener('mousedown',e=>{if(e.target.classList&&e.target.classList.contains('ov'))close()});

function checkLimits(t){if(t.tipo!=='Despesa')return;S.lim.forEach(l=>{if(!desc(l.cat).includes(+t.cat))return;const p=gasto(l.cat)/l.teto*100;if(p>=l.pct){const m=p>=100?`Limite de ${cat(l.cat).nome} ultrapassado.`:`${cat(l.cat).nome} chegou a ${Math.round(p)}% do limite mensal.`;notif(m);toast(m)}})}

/* eventos */
document.addEventListener('click',e=>{const b=e.target.closest('[data-act],[data-auth]');if(!b)return;const a=b.dataset.act;
 if(b.dataset.auth){S.auth=b.dataset.auth;return render()}
 if(a==='x')return close();
 if(a==='logout'){S.user=null;S.auth='login';return render()}
 if(a==='nova-tx')return modal('Nova transação',fld('desc','Descrição','text','required')+fld('valor','Valor (R$)','number','required min="0.01" step="0.01"')+fld('data','Data','date',`required value="${today}"`)+sel('tipo','Tipo',opts(['Despesa','Receita']))+sel('forma','Forma de pagamento',opts(['Pix','Cartão de débito','Cartão de crédito','Boleto','Dinheiro','Transferência']))+sel('cat','Categoria',catOpts(1))+sel('conta','Conta',contaOpts())+fld('comp','Comprovante (opcional)','file','accept="image/*,.pdf"'),'tx');
 if(a==='nova-conta')return modal('Nova conta',fld('nome','Nome','text','required')+sel('tipo','Tipo',opts(['Conta corrente','Poupança','Carteira física']))+fld('ini','Saldo inicial (R$)','number','step="0.01" value="0"'),'conta');
 if(a==='nova-cat')return modal('Nova categoria',fld('nome','Nome','text','required')+sel('pai','Dentro de',`<option value="">Nível principal</option>${catOpts()}`),'cat');
 if(a==='nova-lim')return modal('Definir limite mensal',sel('cat','Categoria',catOpts())+fld('teto','Limite (R$)','number','required min="1" step="0.01"')+fld('pct','Alertar a partir de (%)','number','required min="1" max="100" value="80"'),'lim');
 if(a==='nova-meta')return modal('Nova meta',fld('nome','Nome da meta','text','required')+fld('alvo','Valor final (R$)','number','required min="1"')+fld('aporte','Aporte mensal (R$)','number','required min="1"')+fld('fim','Data de término','date','required'),'meta');
 if(a==='aportar'){S.tmp=+b.dataset.id;return modal('Registrar aporte',fld('v','Valor (R$)','number','required min="1" step="0.01"'),'aporte')}
 if(a==='nova-ag')return modal('Agendar lançamento',fld('desc','Descrição','text','required')+fld('valor','Valor (R$)','number','required min="0.01" step="0.01"')+sel('per','Periodicidade',opts(['Diária','Mensal','Semestral','Anual']))+fld('prox','Próxima data','date',`required value="${today}"`)+sel('cat','Categoria',catOpts(1))+sel('conta','Conta',contaOpts())+sel('tipo','Tipo',opts(['Despesa','Receita'])),'ag');
 if(a==='venc'){S.ag.forEach(g=>{S.tx.push({id:++uid,desc:g.desc,valor:g.valor,data:g.prox,tipo:g.tipo,forma:'Recorrente',cat:g.cat,conta:g.conta,status:'Pendente'});const d=new Date(g.prox+'T12:00');if(g.per==='Diária')d.setDate(d.getDate()+1);else d.setMonth(d.getMonth()+(g.per==='Mensal'?1:g.per==='Semestral'?6:12));g.prox=d.toISOString().slice(0,10)});toast('Pendências geradas. Confirme cada uma.');return view()}
 if(a==='conf'||a==='desc'){const t=S.tx.find(x=>x.id==b.dataset.id);if(a==='conf'){t.status='Efetivada';checkLimits(t);toast('Lançamento confirmado.')}else S.tx=S.tx.filter(x=>x!==t);return view()}
 if(a==='imp-demo')return load('data,descricao,valor\n'+ym+'-03,Supermercado,-620.00\n'+ym+'-06,Farmácia,-48.90\n'+ym+'-06,Pix recebido,150.00\n');
 if(a==='imp-conf'){const n=S.imp.filter(x=>x.sel);n.forEach(x=>S.tx.push({id:++uid,desc:x.desc,valor:Math.abs(x.valor),data:x.data,tipo:x.valor<0?'Despesa':'Receita',forma:'Importado',cat:null,conta:1,status:'Efetivada'}));S.imp=null;toast(n.length+' lançamentos gravados.');return view()}
 if(a==='del'){const d=DEL[b.dataset.t],m=d.chk&&d.chk();if(m!==undefined&&m!==true)return toast(m);S.del={t:b.dataset.t,id:b.dataset.id};return modal('Remover item',`<p>Remover ${d.n}? Esta ação não pode ser desfeita.</p>`,'del','Remover','danger')}
 if(a==='limpar-not'){S.notifs=[];badge();return view()}
 if(a==='pdf')return window.print();
 if(a==='xlsx')return toast('A exportação XLSX será gerada pelo back-end.');
});
document.addEventListener('change',e=>{const t=e.target;
 if(t.dataset.chg==='filtro'){S.filtro=t.value;view()}
 if(t.dataset.chg==='arq'&&t.files[0]){const r=new FileReader();r.onload=()=>load(r.result);r.readAsText(t.files[0])}
 if(t.dataset.chk!==undefined)S.imp[t.dataset.chk].sel=t.checked});
function load(txt){let L=[];
 if(/<STMTTRN>/i.test(txt))(txt.match(/<STMTTRN>[\s\S]*?(?=<\/STMTTRN>|<STMTTRN>|$)/gi)||[]).forEach(b=>{const g=k=>(b.match(new RegExp('<'+k+'>([^<\\r\\n]*)','i'))||[])[1]||'';const d=g('DTPOSTED');L.push({data:d.slice(0,4)+'-'+d.slice(4,6)+'-'+d.slice(6,8),desc:g('MEMO')||g('NAME'),valor:parseFloat(g('TRNAMT'))})});
 else txt.trim().split(/\r?\n/).slice(1).forEach(l=>{const p=l.split(/[,;]/);if(p.length>=3)L.push({data:p[0].trim(),desc:p[1].trim(),valor:parseFloat(p[2])})});
 L=L.filter(x=>x.data&&!isNaN(x.valor));if(!L.length)return toast('Não encontramos lançamentos válidos no arquivo.');
 S.imp=L.map(x=>{const dup=S.tx.some(t=>t.data===x.data&&t.valor===Math.abs(x.valor));return{...x,dup,sel:!dup}});view()}

document.addEventListener('submit',e=>{e.preventDefault();const f=e.target,k=f.dataset.f,d=Object.fromEntries(new FormData(f));
 if(k==='login'){S.user={nome:d.email.split('@')[0],email:d.email};last=Date.now();S.view='dashboard';history.replaceState(null,'','#dashboard');return render()}
 if(k==='cad'){S.auth='login';render();return toast('Conta criada. Entre para continuar.')}
 if(k==='rec'){S.auth='login';render();return toast('Link de redefinição enviado.')}
 if(k==='del'){DEL[S.del.t].f(S.del.id);close();view();badge();return toast('Removido.')}
 if(k==='tx'){const t={id:++uid,desc:d.desc,valor:+d.valor,data:d.data,tipo:d.tipo,forma:d.forma,cat:d.cat?+d.cat:null,conta:+d.conta,status:'Efetivada',comp:d.comp&&d.comp.name?d.comp.name:''};S.tx.push(t);close();view();checkLimits(t);return toast('Transação registrada.')}
 if(k==='conta')S.contas.push({id:++uid,nome:d.nome,tipo:d.tipo,ini:+d.ini||0});
 if(k==='cat'){if(d.pai&&nivel(cat(d.pai))>=3)return toast('Limite de 3 níveis atingido. Escolha outra categoria pai.');S.cats.push({id:++uid,nome:d.nome,pai:d.pai?+d.pai:null})}
 if(k==='lim'){S.lim=S.lim.filter(l=>l.cat!=d.cat);S.lim.push({cat:+d.cat,teto:+d.teto,pct:+d.pct})}
 if(k==='meta')S.metas.push({id:++uid,nome:d.nome,alvo:+d.alvo,aporte:+d.aporte,acum:0,fim:d.fim});
 if(k==='aporte'){const m=S.metas.find(x=>x.id==S.tmp);m.acum=Math.min(m.alvo,m.acum+ +d.v)}
 if(k==='ag')S.ag.push({id:++uid,desc:d.desc,valor:+d.valor,per:d.per,prox:d.prox,cat:d.cat?+d.cat:null,conta:+d.conta,tipo:d.tipo});
 close();view();toast('Salvo.')});
render();
